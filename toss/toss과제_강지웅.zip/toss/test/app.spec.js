import App from '../src/js/app';

describe('Test for Toss App', () => {
  let app;

  beforeEach(() => {
    var container = document.createElement('DIV');

    document.body.appendChild(container);
    app = new App(container);

    app.state.accounts = [
      {
        "corporation": {
          "id": "toss",
          "name": "Toss "
        },
        "account": "",
        "deposit": {
          "amount": 141000,
          "currency": ""
        },
        "fee": 0
      },
      {
        "corporation": {
          "id": "shinhan",
          "name": "Shinhan"
        },
        "account": "4648*****84347",
        "deposit": {
          "amount": null,
          "currency": ""
        },
        "fee" : 500
      }
    ];
  });

  describe('_getBottomMessageWhenToss 함수 테스트', () => {
    it('remittance값이 0일 경우 빈 값을 반환한다.', () => {
      const actual = app._getBottomMessageWhenToss(0, 1000);
      const expected = '';

      expect(actual).toEqual(expected);
    });

    it('remittance값이 amount보다 클 경우의 메시지 출력', () => {
      const actual = app._getBottomMessageWhenToss(2000, 1000);
      const expected = 'Toss 계좌를 채우고, 무료로 송금하세요';

      expect(actual).toEqual(expected);
    });

    it('remittance값이 amount보다 작거나 같을 경우의 메시지 출력', () => {
      const actual = app._getBottomMessageWhenToss(900, 1000);
      const expected = 'Toss 계좌 / <strong>수수료 무료</strong>';

      expect(actual).toEqual(expected);
    });
  });

  describe('_getBottomMessage 함수 테스트', () => {
    it('토스 계좌가 아닐 경우의 bottom message 반환', () => {
      app.state.selectedAccountIndex = 1;
      app.state.freeRemittance = 3;

      const actual = app._getBottomMessage();
      const expected = '무료 송금 <strong>3회 남음</strong> (월 5회)';

      expect(actual).toEqual(expected);
    });
  });

  describe('_isActiveSendButton 함수 테스트', () => {
    it('송금액이 없을 경우에 false 반환', () => {
      app.state.remittance = 0;

      const actual = app._isActiveSendButton();
      const expected = false;

      expect(actual).toEqual(expected);
    });

    it('토스 계좌이면서 잔액이 송금액보다 크거나 같으면 true 반환', () => {
      app.state.remittance = 1000;
      app.state.selectedAccountIndex = 0;

      const actual = app._isActiveSendButton();
      const expected = true;

      expect(actual).toEqual(expected);
    });

    it('토스 계좌이면서 잔액이 송금액보다 작으면 false 반환', () => {
      app.state.remittance = 100000000;
      app.state.selectedAccountIndex = 0;

      const actual = app._isActiveSendButton();
      const expected = false;

      expect(actual).toEqual(expected);
    });

    it('토스 계좌가 아니면서 무료 송금 횟수가 1회 이상일 경우 true 반환', () => {
      app.state.remittance = 1000;
      app.state.selectedAccountIndex = 1;
      app.state.freeRemittance = 1;

      const actual = app._isActiveSendButton();
      const expected = true;

      expect(actual).toEqual(expected);
    });

    it('토스 계좌가 아니면서 무료 송금 횟수가 1회 미만일 경우 false 반환', () => {
      app.state.remittance = 1000;
      app.state.selectedAccountIndex = 1;
      app.state.freeRemittance = 0;

      const actual = app._isActiveSendButton();
      const expected = false;

      expect(actual).toEqual(expected);
    });
  });
});
