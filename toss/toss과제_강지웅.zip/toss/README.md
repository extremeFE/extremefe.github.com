# Toss Homework 

## Install
* `npm install`
* node_modules에 npm 모듈 설치됨

## Dev
* `npm run dev` 명령어로 webpack-dev-server 실행
* http://localhost:8080/ 으로 접근

## Build (Production Version)
* `npm run build`
* `public/toss.js`로 생성됨
* minify, uglify 적용
* 빌드 버전 실행 : `public/index.html`

## Test
* `npm test`

## Demo
* http://extremefe.github.io/toss/

## 주의 사항
* 송금액 입력 화면 동작은 모바일 폰 Demo에 최적화 되었습니다.
* 따라서 데스크탑 브라우저에서 확인하실 경우 송금액 입력란에 클릭을 해도 포커스가 보이지 않습니다.

