import dom from './dom';

const CLASS_NAME = 'send-button';

class SendButton {
  constructor(eventBus) {
    const html = '<button>보내기</button>';

    this.eventBus = eventBus;
    this.state = {
      isActive: false
    };
    this.container = dom.create('send-button', html);

    this._attachEvent();
  }

  _attachEvent() {
    this.container.addEventListener('click', () => {
      if (!this.state.isActive) {
        return;
      }
      this.eventBus.$emit('SEND');
    });
  }

  /**
   * 송금 버튼 활성화
   * @param {Boolean} active - 송금 버튼의 활성화 상태
   */
  activate(active) {
    let className = CLASS_NAME;

    if (active) {
      className += ' active';
    }

    this.state.isActive = active;
    this.container.className = className;
  }
};

export default SendButton;
