import EventBus from './event-bus';
import api from './api';
import RemittanceField from './remittance-field';
import AccountSelector from './account-selector';
import BottomMessageBar from './bottom-message-bar';
import SendButton from './send-button';

class App {
  constructor(container) {
    this.container = container;

    this.state = {
      limit: null, // toss 계좌 송금 한도 및 남은 계좌
      remittance: 0, // 송금액
      freeRemittance: 0, // 타 계좌 무료 송금 가능 횟수
      selectedAccountIndex: 0,
      selectedAccount: null // 선택된 계좌
    };

    /**
     * 컴포넌트에서 부모에게 요청하기 위한 event bus
     */
    this.eventBus = new EventBus();
    this.components = {};

    this._addComponents();
    this._fetchData().then(this._render.bind(this));
    this._attachCustomEvent();
  }

  _addComponent(Component, name) {
    const component = new Component(this.eventBus);

    this.container.appendChild(component.container);
    this.components[name] = component;
  }

  _addComponents() {
    this._addComponent(RemittanceField, 'remittanceField');
    this._addComponent(AccountSelector, 'accountSelector');
    this._addComponent(BottomMessageBar, 'bottomMessageBar');
    this._addComponent(SendButton, 'sendButton');
  }

  async _fetchData() {
    const userInfo = (await api.fetchUserInfo()).data;
    const accounts = (await api.fetchUserAccounts({id: userInfo.id})).data.reverse();
    const state = this.state;

    state.limit = userInfo.limit;
    state.freeRemittance = userInfo.freeRemittance;
    state.accounts = accounts;
    state.selectedAccountIndex = 0;
  }

  _render() {
    const components = this.components;
    const state = this.state;

    components.remittanceField.render(state.limit.daily);
    components.accountSelector.render(state.accounts);
  }

  /**
   * 송금액 변경 시 동작
   * - eventBus "CHANGE_REMITTANCE"
   * @param {Number} remittance - 송금액
   */
  _changeRemittance(remittance) {
    this.state.remittance = remittance || 0;
    this._showBottomMessage();
    this._activateSendButton();
  }

  /**
   * 송금 계좌가 토스일 경우 메시지 얻기
   * @param {Number} remittance - 송금액
   * @param {Number} amout - 계좌 잔액
   */
  _getBottomMessageWhenToss(remittance, amount) {
    let message = '';

    if (!remittance) {
      return message;
    }

    if (remittance > amount) {
      message = 'Toss 계좌를 채우고, 무료로 송금하세요';
    } else {
      message = 'Toss 계좌 / <strong>수수료 무료</strong>';
    }

    return message;
  }

  /**
   * bottom message bar 영역에 보여질 메시지 반환
   */
  _getBottomMessage() {
    const { accounts, selectedAccountIndex, remittance, freeRemittance } = this.state;
    const { corporation, deposit } = accounts[selectedAccountIndex];
    let message = '';

    if (this._isToss(corporation.id)) {
      message = this._getBottomMessageWhenToss(remittance, deposit.amount);
    } else {
      message = `무료 송금 <strong>${ freeRemittance }회 남음</strong> (월 5회)`;
    }

    return message;
  }

  _isToss(id) {
    return id === 'toss';
  }

  /**
   * 송금액 입력이나 송금 계좌 선택 시 bottomMessageBar 컴포넌트에 상태에 따른 메시지 전달
   */
  _showBottomMessage() {
    this.components.bottomMessageBar.showMessage(this._getBottomMessage());
  }

  /**
   * 전송 버튼의 활성 상태 반환
   */
  _isActiveSendButton() {
    const { accounts, selectedAccountIndex, freeRemittance, remittance } = this.state;
    const { corporation, deposit } = accounts[selectedAccountIndex];
    let active = true;

    if (!remittance) {
      active = false;
    } else if (this._isToss(corporation.id)) {
      active = deposit.amount >= remittance;
    } else {
      active = freeRemittance > 0;
    }

    return active;
  }

  /**
   * 전송 버튼 활성화
   */
  _activateSendButton() {
    const active = this._isActiveSendButton();
    this.components.sendButton.activate(active);
  }


  /**
   * 송금 계좌 선택 시 동작
   * - eventBus "SELECT_ACCOUNT"
   * @param {Number} index - 선택된 계좌 정보의 index
   */
  _selectAccount(index) {
    this.state.selectedAccountIndex = index;
    this._showBottomMessage();
    this._activateSendButton();
  }

  _printResult() {
    const { limit, remittance, accounts, selectedAccountIndex } = this.state;
    const { corporation, deposit, account } = accounts[selectedAccountIndex];

    console.log('=======================');
    console.log('송금액:', remittance);
    console.log('송금 계좌:', corporation.name);

    if (this._isToss(corporation.id)) {
      console.log('잔액:', deposit.amount);
    } else {
      console.log('계좌 번호:', account);
    }
    console.log('=======================');
  }

  /**
   * 송금 버튼 클릭 시 동작
   * - eventBus "SEND"
   */
  _send() {
    const state = this.state;
    const selectedAccountIndex = state.selectedAccountIndex;
    const { corporation, deposit } = state.accounts[selectedAccountIndex];

    if (this._isToss(corporation.id)) { // toss 계좌일 경우 남은 금액에서 송금액을 차감함
      deposit.amount -= state.remittance;
    } else if (state.freeRemittance > 0) { // toss 계좌가 아닐 경우 무료 송금 횟수 차감
      state.freeRemittance -= 1;
    }

    this._printResult();

    this.components.remittanceField.initInput();
    this.components.accountSelector.render(state.accounts, selectedAccountIndex);
  }

  /**
   * event bus를 통해 컴포넌트로 부터 전달되는 event 등록
   */
  _attachCustomEvent() {
    this.eventBus.$on('CHANGE_REMITTANCE', this._changeRemittance.bind(this));
    this.eventBus.$on('SELECT_ACCOUNT', this._selectAccount.bind(this));
    this.eventBus.$on('SEND', this._send.bind(this));
  }
};

export default App;
