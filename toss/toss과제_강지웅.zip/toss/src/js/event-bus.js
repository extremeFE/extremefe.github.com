class EventBus {
  constructor() {
    this.eventMap = {};
  }

  $on(name, action) {
    this.eventMap[name] = action;
  }

  $emit(name, ...args) {
    const eventAction = this.eventMap[name];

    if (eventAction) {
      eventAction(...args);
    }
  }
}

export default EventBus;
