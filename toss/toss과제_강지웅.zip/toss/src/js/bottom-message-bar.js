import dom from './dom';

const CLASS_NAME = 'bottom-message-bar';

class BottomMessageBar {
  constructor() {
    const html = '<div class="message"></div>';

    this.container = dom.create(CLASS_NAME, html);
    this.messageEl = this.container.querySelector('.message');
  }

  showMessage(message) {
    let className = CLASS_NAME;

    if (message) {
      className += ' show';
    }

    this.messageEl.innerHTML = message;
    this.container.className = className;
  }
};

export default BottomMessageBar;
