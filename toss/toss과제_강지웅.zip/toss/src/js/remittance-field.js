import dom from './dom';
import html from 'html-loader!../html/remittance-field.html';

class RemittanceField {
  constructor(eventBus) {
    const container = dom.create('remittance-field', html);

    this.eventBus = eventBus;
    this.container = container;
    this.state = {
      dailyLimit: 0
    };

    /**
     * 입력 input element
     * - 화면에 보이지 않으며 viewEl 영역 클릭 시 focus가 주어짐
     */
    this.inputEl = container.querySelector('input');

    /**
     * 송금액을 표시하는 element
     * - formatting 하여 표시
     */
    this.viewEl = container.querySelector('.input-view');

    /**
     * 1일 최대 송금 가능액 표시 element
     */
    this.dailyLimitEl = container.querySelector('.daily-limit');

    /**
     * 입력 송금액 상태에 따라 메시지를 표시하는 element
     */
    this.messageEl = container.querySelector('.remittance-message');
    this.NumberFormat = new Intl.NumberFormat();

    this._attachEvent();
  }

  /**
   * 송금액 표시
   * @param {Number} value - 송금액
   */
  _renderInputView(value) {
    this.viewEl.innerHTML = `${ this.NumberFormat.format(value) } 원`;
  }

  /**
   * 숫자만 반환
   */
  _filterNumber(value) {
    const filterd = value.replace(/[^0-9]/g, '');

    return filterd ? parseInt(filterd, 10) : '';
  }

  /**
   * 한글 금액 생성 - 만원 단위와 원 단위를 구분하여 표현
   * @param {Number} value - 송금액
   */
  _formatKorean(value) {
    const strValue = value + '';
    const tenThousandMore = parseInt(strValue.slice(0, -4), 10);
    const tenThousandUnder = parseInt(strValue.slice(-4), 10);

    let formatted = `${ this.NumberFormat.format(tenThousandMore) }만 `;

    if (tenThousandUnder > 0) {
      formatted += this.NumberFormat.format(tenThousandUnder);
    }

    return `${ formatted }원`;
  }

  /**
   * 송금액에 따라 표시하는 메시지 반환
   * @param {Number} value - 제한금액 처리 하지 않은 송금액
   * @param {Number} limited - 제한금액 처리한 송금액
   */
  _getMessage(value, limited) {
    let message = '';

    if (value > limited) {
      const formatted = this.NumberFormat.format(limited);
      message = `<span class="warning">1일 ${ formatted }원 까지만 이체할 수 있습니다.</span>`;
    } else if (value && value > 10000) {
      message = this._formatKorean(value);
    }

    return message;
  }

  _showMessage(value, limited) {
    this.messageEl.innerHTML = this._getMessage(value, limited);
  }

  /**
   * input에 입력 내용 변경 시 동작
   * - event bus를 통해 "CHANGE_REMITTANCE" emit
   */
  _changeRemittance() {
    const value = this.inputEl.value;
    const filterd = this._filterNumber(value);
    const dailyLimit = this.state.dailyLimit;
    const limited = filterd ? Math.min(filterd, dailyLimit) : filterd;

    if (value !== limited) {
      this.inputEl.value = limited;
    }

    this._renderInputView(limited);
    this._showMessage(filterd, limited);

    this.eventBus.$emit('CHANGE_REMITTANCE', limited);
  }

  _attachEvent() {
    this.viewEl.addEventListener('click', () => {
      this.inputEl.focus();
    });
    this.inputEl.addEventListener('input', this._changeRemittance.bind(this));
  }

  initInput() {
    this.inputEl.value = '';
    this._changeRemittance();
  }

  /**
   * 일일 송금 제한 금액 표시 및 limit 설정
   * @param {Number} limit - 일일 송금 제한 금액
   */
  render(limit) {
    this.state.dailyLimit = limit;
    this.dailyLimitEl.innerHTML = `(최대 ${ this.NumberFormat.format(limit) }원)`;
    this.initInput();
  }
};

export default RemittanceField;
