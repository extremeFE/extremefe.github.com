export default {
  create(className = '', html = '') {
    const element = document.createElement('DIV');

    element.className = className;
    element.innerHTML = html;

    return element;
  }
};
