import Swiper from 'swiper';
import dom from './dom';
import baseHtml from 'html-loader!../html/account-selector.html';
import swiperTemplate from '../html/account-swiper.hbs';

const SIDE_PADDING = 23;

class AccountSelector {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.container = dom.create('account-selector', baseHtml);

    /**
     * 송금 계좌를 선택하는 swiper를 담고 있는 element
     */
    this.swiperContainer = this.container.querySelector('.swiper-container');

    /**
     * swiper instance
     */
    this.swiper = null;
  }

  /**
   * swiper 초기화
   * @param {Number} initialSlide - 최초 index
   */
  _initSwiper(initialSlide = 0) {
    this.swiper = new Swiper(this.swiperContainer, {
      initialSlide,
      spaceBetween: 5,
      slidesOffsetBefore: SIDE_PADDING,
      slidesOffsetAfter: -SIDE_PADDING,
      width: window.innerWidth - (SIDE_PADDING * 2),
      pagination: {
        el: '.swiper-pagination',
      }
    });

    this.swiper.on('slideChange', () => {
      this.eventBus.$emit('SELECT_ACCOUNT', this.swiper.activeIndex);
    });
  }

  /**
   * 계좌 선택 swiper 랜더링
   * - 계좌 송금 후에도 호출되어 동작함
   */
  render(accounts, selectedIndex = 0) {
    const Numberformat = new Intl.NumberFormat();
    accounts = accounts.map(({ corporation, deposit, account }) => {
      return {
        name: corporation.name,
        desc: corporation.id === 'toss' ? `${ Numberformat.format(deposit.amount) } 원` : account
      };
    });

    if (this.swiper) {
      this.swiper.destroy();
    }

    this.swiperContainer.innerHTML = swiperTemplate({ accounts });

    this._initSwiper(selectedIndex);
  }
};

export default AccountSelector;
