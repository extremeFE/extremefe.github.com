import App from './app';

(() => {
  const container = document.querySelector('#container');
  window.toss = new App(container);
})();
