export default {
  fetchUserInfo() {
    return Promise.resolve({
      data: {
        "id": "817c2a9",
        "name": "",
        "limit": {
          "daily": 2000000,
          "remain": 2000000
        },
        "freeRemittance": 5
      }
    });
  },
  fetchUserAccounts() {
    return Promise.resolve({
      data: [
        {
          "corporation": {
            "id": "shinhan",
            "name": "Shinhan"
          },
          "account": "4648*****84347",
          "deposit": {
            "amount": null,
            "currency": ""
          },
          "fee" : 500
        },
        {
          "corporation": {
            "id": "toss",
            "name": "Toss "
          },
          "account": "",
          "deposit": {
            "amount": 141000,
            "currency": ""
          },
          "fee": 0
        }
      ]
    });
  }
};
