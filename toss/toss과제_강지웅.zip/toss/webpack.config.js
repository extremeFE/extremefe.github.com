const CopyWebpackPlugin = require('copy-webpack-plugin');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');
const path = require('path');

module.exports = {
  entry: './src/js/index.js',
  output: {
    filename: 'toss.js',
    path: path.resolve(__dirname, 'public')
  },
  devServer: {
    host: '0.0.0.0',
    contentBase: path.join(__dirname, 'public'),
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules|public/,
        loader: 'babel-loader',
        options: {
          babelrc: true
        }
      }, {
        test: /\.hbs$/,
        loader: "handlebars-loader"
      }
    ]
  },
  plugins: [
    new CopyWebpackPlugin([
      { from: 'node_modules/swiper/dist/css/swiper.min.css', to: './' }
    ]),
    new UglifyJSPlugin()
  ]
};
